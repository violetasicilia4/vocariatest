import { motion } from 'motion/react';

const pasos = [
  {
    n: '01',
    titulo: 'Situaciones, no preferencias',
    texto: 'En lugar de "¿te gusta el arte o las ciencias?", te ponemos en contextos reales. Tu respuesta revela cómo pensás.',
    beneficio: '— Sabés cómo pensás, no solo qué te gusta.',
  },
  {
    n: '02',
    titulo: 'Un patrón, no una lista',
    texto: 'No te damos una carrera. Te mostramos cómo procesás el mundo y qué carreras encajan con eso.',
    beneficio: '— Dejás de mirar opciones sueltas y empezás a comparar caminos.',
  },
  {
    n: '03',
    titulo: 'Carreras reales, contexto real',
    texto: 'Más de 130 carreras de universidades argentinas, con contexto laboral incluido.',
    beneficio: '— Pasás del "qué estudiar" al "dónde y con qué salida".',
  },
];

export default function ComoFunciona() {
  return (
    <section className="py-12 sm:py-20 bg-white border-t border-slate-100">
      <div className="max-w-5xl mx-auto px-6">

        {/* Headline */}
        <motion.h2
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.45 }}
          className="font-display text-2xl sm:text-4xl tracking-tight leading-[1.15] mb-10 sm:mb-14"
        >
          <span className="font-normal block text-slate-500 mb-0.5">
            No te preguntamos qué te gusta.
          </span>
          <span className="font-black block text-[#0e1118]">
            Te ponemos en situaciones.
          </span>
        </motion.h2>

        {/* Ítems — stack en mobile, fila en desktop */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 sm:gap-12">
          {pasos.map((p, i) => (
            <motion.div
              key={p.n}
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.1 }}
            >
              <span className="font-mono font-bold text-[12px] text-brand-sky block mb-2">
                {p.n}
              </span>
              <h3 className="font-display font-extrabold text-[16px] sm:text-[17px] text-slate-900 mb-2 leading-tight">
                {p.titulo}
              </h3>
              <p className="text-[13px] sm:text-sm text-slate-500 leading-relaxed font-medium mb-2">
                {p.texto}
              </p>
              <p className="text-[11px] text-slate-400 leading-snug font-normal">
                {p.beneficio}
              </p>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
